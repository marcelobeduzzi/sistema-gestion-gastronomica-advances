import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

// Rutas públicas que no requieren autenticación
const PUBLIC_ROUTES = ["/login", "/forgot-password"]

export function middleware(request: NextRequest) {
  // Por ahora, desactivamos el middleware para permitir el acceso
  return NextResponse.next()

  // Este código se puede habilitar más adelante cuando el sistema de autenticación esté funcionando correctamente
  /*
  const { pathname } = request.nextUrl;
  
  // Verificar si la ruta actual es pública
  const isPublicRoute = PUBLIC_ROUTES.some(route => pathname.startsWith(route));
  
  // Obtener el token de autenticación de las cookies
  const authToken = request.cookies.get('auth-token')?.value;
  
  // Si no es una ruta pública y el usuario no está autenticado, redirigir a login
  if (!isPublicRoute && !authToken) {
    return NextResponse.redirect(new URL('/login', request.url));
  }
  
  return NextResponse.next();
  */
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}

