"use client"

import { useState, useEffect } from "react"
import { DashboardLayout } from "@/app/dashboard-layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DataTable } from "@/components/data-table"
import { StatusBadge } from "@/components/status-badge"
import { ConfirmDialog } from "@/components/confirm-dialog"
import { dbService } from "@/lib/db-service"
import { exportToCSV, formatDate, formatCurrency } from "@/lib/export-utils"
import type { Employee } from "@/types"
import type { ColumnDef } from "@tanstack/react-table"
import { Plus, Pencil, Trash2 } from "lucide-react"
import Link from "next/link"

export default function EmpleadosPage() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [employeeToDelete, setEmployeeToDelete] = useState<string | null>(null)

  useEffect(() => {
    const fetchEmployees = async () => {
      setIsLoading(true)
      try {
        const data = await dbService.getEmployees()
        setEmployees(data)
      } catch (error) {
        console.error("Error al cargar empleados:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchEmployees()
  }, [])

  const handleDeleteEmployee = async () => {
    if (!employeeToDelete) return

    try {
      const success = await dbService.deleteEmployee(employeeToDelete)
      if (success) {
        setEmployees(employees.filter((emp) => emp.id !== employeeToDelete))
      }
    } catch (error) {
      console.error("Error al eliminar empleado:", error)
    } finally {
      setEmployeeToDelete(null)
      setDeleteDialogOpen(false)
    }
  }

  const handleExportCSV = () => {
    exportToCSV(employees, "empleados")
  }

  const columns: ColumnDef<Employee>[] = [
    {
      accessorKey: "firstName",
      header: "Nombre",
      cell: ({ row }) => (
        <div>
          {row.original.firstName} {row.original.lastName}
        </div>
      ),
    },
    {
      accessorKey: "position",
      header: "Cargo",
    },
    {
      accessorKey: "local",
      header: "Local",
    },
    {
      accessorKey: "phone",
      header: "Teléfono",
    },
    {
      accessorKey: "email",
      header: "Email",
    },
    {
      accessorKey: "hireDate",
      header: "Fecha Ingreso",
      cell: ({ row }) => formatDate(row.original.hireDate),
    },
    {
      accessorKey: "terminationDate",
      header: "Fecha Egreso",
      cell: ({ row }) => formatDate(row.original.terminationDate),
    },
    {
      accessorKey: "totalSalary",
      header: "Sueldo Total",
      cell: ({ row }) => formatCurrency(row.original.totalSalary),
    },
    {
      accessorKey: "status",
      header: "Estado",
      cell: ({ row }) => <StatusBadge status={row.original.status} />,
    },
    {
      id: "actions",
      header: "Acciones",
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          <Link href={`/empleados/editar/${row.original.id}`}>
            <Button variant="ghost" size="icon">
              <Pencil className="h-4 w-4" />
              <span className="sr-only">Editar</span>
            </Button>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              setEmployeeToDelete(row.original.id)
              setDeleteDialogOpen(true)
            }}
          >
            <Trash2 className="h-4 w-4" />
            <span className="sr-only">Eliminar</span>
          </Button>
        </div>
      ),
    },
  ]

  return (
    <DashboardLayout>
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Empleados</h2>
            <p className="text-muted-foreground">Gestiona la información de los empleados de todos los locales</p>
          </div>
          <Link href="/empleados/nuevo">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nuevo Empleado
            </Button>
          </Link>
        </div>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Lista de Empleados</CardTitle>
            <CardDescription>Total: {employees.length} empleados registrados</CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable
              columns={columns}
              data={employees}
              searchColumn="firstName"
              searchPlaceholder="Buscar empleado..."
              onExportCSV={handleExportCSV}
              onExportPDF={() => {}}
              onPrint={() => {}}
            />
          </CardContent>
        </Card>

        <ConfirmDialog
          open={deleteDialogOpen}
          onOpenChange={setDeleteDialogOpen}
          title="¿Eliminar empleado?"
          description="Esta acción no se puede deshacer. ¿Estás seguro de que deseas eliminar este empleado?"
          onConfirm={handleDeleteEmployee}
        />
      </div>
    </DashboardLayout>
  )
}

