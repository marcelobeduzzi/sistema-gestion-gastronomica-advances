import type {
  Employee,
  Attendance,
  Payroll,
  PayrollDetail,
  DeliveryStats,
  Audit,
  AuditItem,
  Billing,
  Balance,
  Report,
  Local,
  DeliveryPlatform,
  WorkShift,
} from "@/types"

// Datos simulados para locales
const locales: Local[] = [
  "BR Cabildo",
  "BR Carranza",
  "BR Pacifico",
  "BR Lavalle",
  "BR Rivadavia",
  "BR Aguero",
  "BR Dorrego",
  "Dean & Dennys",
  "Administración",
]

// Datos simulados para empleados
const employees: Employee[] = [
  {
    id: "1",
    firstName: "Juan",
    lastName: "Pérez",
    documentId: "28456789",
    documentType: "DNI",
    phone: "11-5555-1234",
    email: "juan.perez@quadrifoglio.com",
    address: "Av. Corrientes 1234, CABA",
    birthDate: "1990-05-15",
    hireDate: "2022-03-10",
    position: "Mesero",
    local: "BR Cabildo",
    workShift: "morning",
    baseSalary: 150000,
    bankSalary: 50000,
    totalSalary: 200000,
    status: "active",
    role: "waiter",
  },
  {
    id: "2",
    firstName: "María",
    lastName: "López",
    documentId: "30123456",
    documentType: "DNI",
    phone: "11-5555-5678",
    email: "maria.lopez@quadrifoglio.com",
    address: "Av. Santa Fe 4321, CABA",
    birthDate: "1988-10-20",
    hireDate: "2021-11-15",
    position: "Cocinera",
    local: "BR Cabildo",
    workShift: "afternoon",
    baseSalary: 180000,
    bankSalary: 60000,
    totalSalary: 240000,
    status: "active",
    role: "kitchen",
  },
  {
    id: "3",
    firstName: "Carlos",
    lastName: "Rodríguez",
    documentId: "25789456",
    documentType: "DNI",
    phone: "11-5555-9012",
    email: "carlos.rodriguez@quadrifoglio.com",
    address: "Av. Cabildo 2345, CABA",
    birthDate: "1992-03-25",
    hireDate: "2022-01-20",
    position: "Cajero",
    local: "BR Carranza",
    workShift: "full_time",
    baseSalary: 160000,
    bankSalary: 55000,
    totalSalary: 215000,
    status: "active",
    role: "cashier",
  },
  {
    id: "4",
    firstName: "Ana",
    lastName: "Martínez",
    documentId: "27654321",
    documentType: "DNI",
    phone: "11-5555-3456",
    email: "ana.martinez@quadrifoglio.com",
    address: "Av. Rivadavia 5678, CABA",
    birthDate: "1985-12-10",
    hireDate: "2020-08-05",
    position: "Gerente",
    local: "BR Pacifico",
    workShift: "full_time",
    baseSalary: 250000,
    bankSalary: 100000,
    totalSalary: 350000,
    status: "active",
    role: "manager",
  },
  {
    id: "5",
    firstName: "Roberto",
    lastName: "Sánchez",
    documentId: "29876543",
    documentType: "DNI",
    phone: "11-5555-7890",
    email: "roberto.sanchez@quadrifoglio.com",
    address: "Av. Belgrano 9012, CABA",
    birthDate: "1991-07-30",
    hireDate: "2021-05-12",
    terminationDate: "2023-02-28",
    position: "Mesero",
    local: "BR Carranza",
    workShift: "night",
    baseSalary: 150000,
    bankSalary: 50000,
    totalSalary: 200000,
    status: "inactive",
    role: "waiter",
    workedDays: 292, // Calculado: fecha_egreso - fecha_ingreso
  },
  {
    id: "6",
    firstName: "Laura",
    lastName: "Gómez",
    documentId: "31234567",
    documentType: "DNI",
    phone: "11-5555-2345",
    email: "laura.gomez@quadrifoglio.com",
    address: "Av. Callao 3456, CABA",
    birthDate: "1993-09-18",
    hireDate: "2022-06-01",
    position: "Administrativa",
    local: "Administración",
    workShift: "full_time",
    baseSalary: 200000,
    bankSalary: 70000,
    totalSalary: 270000,
    status: "active",
    role: "admin",
  },
  {
    id: "7",
    firstName: "Diego",
    lastName: "Fernández",
    documentId: "26543210",
    documentType: "DNI",
    phone: "11-5555-6789",
    email: "diego.fernandez@quadrifoglio.com",
    address: "Av. Córdoba 7890, CABA",
    birthDate: "1987-04-05",
    hireDate: "2021-02-15",
    position: "Cocinero",
    local: "BR Pacifico",
    workShift: "morning",
    baseSalary: 180000,
    bankSalary: 60000,
    totalSalary: 240000,
    status: "active",
    role: "kitchen",
  },
  {
    id: "8",
    firstName: "Sofía",
    lastName: "Torres",
    documentId: "32345678",
    documentType: "DNI",
    phone: "11-5555-0123",
    email: "sofia.torres@quadrifoglio.com",
    address: "Av. Entre Ríos 1234, CABA",
    birthDate: "1994-11-22",
    hireDate: "2022-09-10",
    position: "Mesera",
    local: "BR Cabildo",
    workShift: "afternoon",
    baseSalary: 150000,
    bankSalary: 50000,
    totalSalary: 200000,
    status: "active",
    role: "waiter",
  },
  {
    id: "9",
    firstName: "Javier",
    lastName: "Díaz",
    documentId: "28901234",
    documentType: "DNI",
    phone: "11-5555-4567",
    email: "javier.diaz@quadrifoglio.com",
    address: "Av. Pueyrredón 5678, CABA",
    birthDate: "1989-08-12",
    hireDate: "2021-07-20",
    position: "Cajero",
    local: "BR Cabildo",
    workShift: "night",
    baseSalary: 160000,
    bankSalary: 55000,
    totalSalary: 215000,
    status: "active",
    role: "cashier",
  },
  {
    id: "10",
    firstName: "Valentina",
    lastName: "Ruiz",
    documentId: "33456789",
    documentType: "DNI",
    phone: "11-5555-8901",
    email: "valentina.ruiz@quadrifoglio.com",
    address: "Av. Scalabrini Ortiz 9012, CABA",
    birthDate: "1995-02-14",
    hireDate: "2023-01-05",
    position: "Mesera",
    local: "BR Carranza",
    workShift: "part_time",
    baseSalary: 120000,
    bankSalary: 40000,
    totalSalary: 160000,
    status: "active",
    role: "waiter",
  },
  {
    id: "11",
    firstName: "Martín",
    lastName: "González",
    documentId: "27123456",
    documentType: "DNI",
    phone: "11-5555-2468",
    email: "martin.gonzalez@quadrifoglio.com",
    address: "Av. Libertador 1357, CABA",
    birthDate: "1988-06-25",
    hireDate: "2021-03-15",
    position: "Supervisor",
    local: "Administración",
    workShift: "full_time",
    baseSalary: 220000,
    bankSalary: 80000,
    totalSalary: 300000,
    status: "active",
    role: "supervisor",
  },
  {
    id: "12",
    firstName: "Lucía",
    lastName: "Fernández",
    documentId: "29654321",
    documentType: "DNI",
    phone: "11-5555-1357",
    email: "lucia.fernandez@quadrifoglio.com",
    address: "Av. Córdoba 2468, CABA",
    birthDate: "1990-11-10",
    hireDate: "2022-02-01",
    position: "Encargada",
    local: "BR Lavalle",
    workShift: "full_time",
    baseSalary: 200000,
    bankSalary: 70000,
    totalSalary: 270000,
    status: "active",
    role: "manager",
  },
]

// Datos simulados para asistencias
const generateAttendances = (): Attendance[] => {
  const attendances: Attendance[] = []
  const today = new Date()

  // Generar asistencias para los últimos 30 días para cada empleado activo
  employees
    .filter((emp) => emp.status === "active")
    .forEach((employee) => {
      for (let i = 0; i < 30; i++) {
        const date = new Date()
        date.setDate(today.getDate() - i)

        // No generar asistencias para fines de semana
        const dayOfWeek = date.getDay()
        if (dayOfWeek === 0 || dayOfWeek === 6) continue

        // Determinar horarios esperados según turno
        let expectedCheckIn = ""
        let expectedCheckOut = ""

        switch (employee.workShift) {
          case "morning":
            expectedCheckIn = "08:00"
            expectedCheckOut = "16:00"
            break
          case "afternoon":
            expectedCheckIn = "16:00"
            expectedCheckOut = "00:00"
            break
          case "night":
            expectedCheckIn = "00:00"
            expectedCheckOut = "08:00"
            break
          case "full_time":
            expectedCheckIn = "09:00"
            expectedCheckOut = "18:00"
            break
          case "part_time":
            expectedCheckIn = "18:00"
            expectedCheckOut = "22:00"
            break
        }

        // Generar variaciones aleatorias para check-in y check-out
        const lateMinutes = Math.random() > 0.7 ? Math.floor(Math.random() * 30) : 0
        const earlyDepartureMinutes = Math.random() > 0.8 ? Math.floor(Math.random() * 20) : 0

        // Calcular check-in y check-out reales
        const [checkInHour, checkInMinute] = expectedCheckIn.split(":").map(Number)
        const checkInDate = new Date(date)
        checkInDate.setHours(checkInHour, checkInMinute + lateMinutes)

        const [checkOutHour, checkOutMinute] = expectedCheckOut.split(":").map(Number)
        const checkOutDate = new Date(date)
        checkOutDate.setHours(checkOutHour, checkOutMinute - earlyDepartureMinutes)

        // Formatear check-in y check-out
        const formatTime = (d: Date) => {
          return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`
        }

        const checkIn = formatTime(checkInDate)
        const checkOut = formatTime(checkOutDate)

        // Determinar si es feriado (simulado)
        const isHoliday = Math.random() > 0.95

        // Determinar si está ausente (simulado)
        const isAbsent = Math.random() > 0.95

        // Determinar si la ausencia está justificada (simulado)
        const isJustified = isAbsent && Math.random() > 0.3

        attendances.push({
          id: `${employee.id}-${date.toISOString().split("T")[0]}`,
          employeeId: employee.id,
          date: date.toISOString().split("T")[0],
          checkIn: isAbsent ? "" : checkIn,
          checkOut: isAbsent ? "" : checkOut,
          expectedCheckIn,
          expectedCheckOut,
          lateMinutes: isAbsent ? 0 : lateMinutes,
          earlyDepartureMinutes: isAbsent ? 0 : earlyDepartureMinutes,
          isHoliday,
          isAbsent,
          isJustified,
          justificationDocument: isJustified ? "certificado_medico.pdf" : undefined,
          notes: isAbsent ? "Ausente" : isHoliday ? "Feriado trabajado" : undefined,
        })
      }
    })

  return attendances
}

const attendances = generateAttendances()

// Datos simulados para nóminas
const generatePayrolls = (): { payrolls: Payroll[]; payrollDetails: PayrollDetail[] } => {
  const payrolls: Payroll[] = []
  const payrollDetails: PayrollDetail[] = []
  const currentDate = new Date()
  const currentMonth = currentDate.getMonth() + 1
  const currentYear = currentDate.getFullYear()

  // Generar nóminas para los últimos 3 meses para cada empleado
  employees.forEach((employee) => {
    for (let i = 0; i < 3; i++) {
      const month = currentMonth - i <= 0 ? 12 + (currentMonth - i) : currentMonth - i
      const year = currentMonth - i <= 0 ? currentYear - 1 : currentYear

      // Calcular deducciones y adiciones basadas en asistencias
      const monthAttendances = attendances.filter((att) => {
        const attDate = new Date(att.date)
        return attDate.getMonth() + 1 === month && attDate.getFullYear() === year && att.employeeId === employee.id
      })

      // Calcular valor del minuto
      const dailySalary = employee.totalSalary / 30
      const minuteValue = dailySalary / 480 // 8 horas = 480 minutos

      let totalDeductions = 0
      let totalAdditions = 0

      const payrollId = `${employee.id}-${year}-${month}`

      // Procesar cada asistencia para calcular deducciones y adiciones
      monthAttendances.forEach((att) => {
        // Deducciones por llegadas tarde
        if (att.lateMinutes > 10) {
          // 10 minutos de tolerancia
          const deductionMinutes = att.lateMinutes - 10
          const deductionAmount = deductionMinutes * minuteValue
          totalDeductions += deductionAmount

          payrollDetails.push({
            id: `${payrollId}-late-${att.date}`,
            payrollId,
            type: "deduction",
            concept: `Llegada tarde (${deductionMinutes} min)`,
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Deducciones por salidas anticipadas
        if (att.earlyDepartureMinutes > 0) {
          const deductionAmount = att.earlyDepartureMinutes * minuteValue
          totalDeductions += deductionAmount

          payrollDetails.push({
            id: `${payrollId}-early-${att.date}`,
            payrollId,
            type: "deduction",
            concept: `Salida anticipada (${att.earlyDepartureMinutes} min)`,
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Deducciones por ausencias injustificadas
        if (att.isAbsent && !att.isJustified) {
          const deductionAmount = dailySalary
          totalDeductions += deductionAmount

          payrollDetails.push({
            id: `${payrollId}-absent-${att.date}`,
            payrollId,
            type: "deduction",
            concept: "Ausencia injustificada",
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Adiciones por feriados trabajados
        if (att.isHoliday && !att.isAbsent) {
          const additionAmount = dailySalary
          totalAdditions += additionAmount

          payrollDetails.push({
            id: `${payrollId}-holiday-${att.date}`,
            payrollId,
            type: "addition",
            concept: "Feriado trabajado",
            amount: additionAmount,
            date: att.date,
          })
        }
      })

      // Calcular salario final
      const finalHandSalary = employee.baseSalary - totalDeductions + totalAdditions

      // Determinar si ya está pagado (los meses anteriores sí, el actual no)
      const isPaidHand = i > 0
      const isPaidBank = i > 0

      payrolls.push({
        id: payrollId,
        employeeId: employee.id,
        month,
        year,
        baseSalary: employee.baseSalary,
        bankSalary: employee.bankSalary,
        deductions: totalDeductions,
        additions: totalAdditions,
        finalHandSalary,
        totalSalary: finalHandSalary + employee.bankSalary,
        isPaidHand,
        isPaidBank,
        handPaymentDate: isPaidHand ? `${year}-${month}-10` : undefined,
        bankPaymentDate: isPaidBank ? `${year}-${month}-05` : undefined,
        details: [],
      })
    }
  })

  // Asignar detalles a cada nómina
  payrolls.forEach((payroll) => {
    payroll.details = payrollDetails.filter((detail) => detail.payrollId === payroll.id)
  })

  return { payrolls, payrollDetails }
}

const { payrolls, payrollDetails } = generatePayrolls()

// Datos simulados para estadísticas de delivery
const generateDeliveryStats = (): DeliveryStats[] => {
  const stats: DeliveryStats[] = []
  const platforms: DeliveryPlatform[] = ["PedidosYa", "Rappi", "MercadoPago"]
  const currentDate = new Date()
  const currentWeek = Math.ceil(currentDate.getDate() / 7)
  const currentYear = currentDate.getFullYear()

  // Generar estadísticas para las últimas 8 semanas para cada plataforma y local
  locales
    .filter((local) => local !== "Administración")
    .forEach((local) => {
      platforms.forEach((platform) => {
        for (let i = 0; i < 8; i++) {
          const week = currentWeek - i <= 0 ? 52 + (currentWeek - i) : currentWeek - i
          const year = currentWeek - i <= 0 ? currentYear - 1 : currentYear

          // Generar datos aleatorios para cada estadística
          const orderCount = Math.floor(Math.random() * 100) + 50
          const revenue = orderCount * (Math.floor(Math.random() * 1000) + 1000)
          const complaints = Math.floor(Math.random() * 5)
          const rating = Math.random() * 2 + 3 // Rating entre 3 y 5

          stats.push({
            id: `${platform}-${local}-${year}-${week}`,
            platform,
            week,
            year,
            orderCount,
            revenue,
            complaints,
            rating,
            local,
          })
        }
      })
    })

  return stats
}

const deliveryStats = generateDeliveryStats()

// Datos simulados para auditorías
const generateAuditItems = (): AuditItem[] => {
  const categories = [
    { name: "Limpieza", items: ["Pisos", "Baños", "Cocina", "Mesas", "Vitrinas", "Depósito", "Exterior"] },
    { name: "Orden", items: ["Cocina", "Salón", "Depósito", "Caja", "Mostrador"] },
    {
      name: "Operatividad",
      items: ["Equipos de cocina", "Caja registradora", "Terminales de pago", "Iluminación", "Aire acondicionado"],
    },
    {
      name: "Temperaturas",
      items: ["Heladeras", "Freezers", "Exhibidores", "Hornos", "Alimentos calientes", "Alimentos fríos"],
    },
    {
      name: "Procedimientos",
      items: [
        "Apertura",
        "Cierre",
        "Preparación de alimentos",
        "Atención al cliente",
        "Manejo de reclamos",
        "Limpieza",
      ],
    },
    {
      name: "Legales",
      items: ["Habilitaciones", "Libreta sanitaria", "Extintores", "Salidas de emergencia", "Señalética"],
    },
    {
      name: "Nómina",
      items: ["Presentismo", "Uniformes", "Higiene personal", "Conocimiento de productos", "Atención al cliente"],
    },
  ]

  const items: AuditItem[] = []
  let id = 1
  let totalValue = 0

  // Distribuir 150 puntos entre todas las categorías y sus items
  categories.forEach((category) => {
    const categoryValue = Math.floor(150 / categories.length)
    const itemValue = Math.floor(categoryValue / category.items.length)

    category.items.forEach((item) => {
      items.push({
        id: id.toString(),
        category: category.name,
        name: item,
        value: itemValue,
        completed: false,
      })
      id++
      totalValue += itemValue
    })
  })

  // Ajustar el último item para que el total sea exactamente 150
  if (totalValue !== 150 && items.length > 0) {
    const lastItem = items[items.length - 1]
    lastItem.value += 150 - totalValue
  }

  return items
}

const auditItems = generateAuditItems()

// Generar auditorías de ejemplo
const generateAudits = (): Audit[] => {
  const audits: Audit[] = []
  const supervisors = employees.filter((emp) => emp.role === "supervisor")
  const managers = employees.filter((emp) => emp.role === "manager")

  if (supervisors.length === 0 || managers.length === 0) return audits

  locales
    .filter((local) => local !== "Administración")
    .forEach((local) => {
      const supervisor = supervisors[Math.floor(Math.random() * supervisors.length)]
      const manager = managers[Math.floor(Math.random() * managers.length)]

      // Generar una auditoría para cada local
      const date = new Date()
      date.setDate(date.getDate() - Math.floor(Math.random() * 30))

      const shifts: WorkShift[] = ["morning", "afternoon", "night"]
      const shift = shifts[Math.floor(Math.random() * shifts.length)]

      // Copiar los items de auditoría y marcar algunos como completados
      const items = auditItems.map((item) => ({
        ...item,
        completed: Math.random() > 0.3, // 70% de probabilidad de estar completado
      }))

      // Calcular puntaje total
      const totalScore = items.reduce((sum, item) => sum + (item.completed ? item.value : 0), 0)

      audits.push({
        id: `${local}-${date.toISOString().split("T")[0]}`,
        localId: local,
        local,
        date: date.toISOString().split("T")[0],
        shift,
        supervisorId: supervisor.id,
        supervisorName: `${supervisor.firstName} ${supervisor.lastName}`,
        managerId: manager.id,
        managerName: `${manager.firstName} ${manager.lastName}`,
        totalScore,
        items,
      })
    })

  return audits
}

const audits = generateAudits()

// Generar datos de facturación
const generateBillings = (): Billing[] => {
  const billings: Billing[] = []
  const currentDate = new Date()
  const currentMonth = currentDate.getMonth() + 1
  const currentYear = currentDate.getFullYear()

  locales
    .filter((local) => local !== "Administración")
    .forEach((local) => {
      // Generar facturación para los últimos 12 meses
      for (let i = 0; i < 12; i++) {
        const month = currentMonth - i <= 0 ? 12 + (currentMonth - i) : currentMonth - i
        const year = currentMonth - i <= 0 ? currentYear - 1 : currentYear

        // Generar monto aleatorio entre 1,000,000 y 5,000,000
        const amount = Math.floor(Math.random() * 4000000) + 1000000

        billings.push({
          id: `${local}-${year}-${month}`,
          localId: local,
          local,
          month,
          year,
          amount,
        })
      }
    })

  return billings
}

const billings = generateBillings()

// Generar datos de balances
const generateBalances = (): Balance[] => {
  const balances: Balance[] = []
  const currentDate = new Date()
  const currentMonth = currentDate.getMonth() + 1
  const currentYear = currentDate.getFullYear()

  locales
    .filter((local) => local !== "Administración")
    .forEach((local) => {
      // Generar balances para los últimos 12 meses
      for (let i = 0; i < 12; i++) {
        const month = currentMonth - i <= 0 ? 12 + (currentMonth - i) : currentMonth - i
        const year = currentMonth - i <= 0 ? currentYear - 1 : currentYear

        // Generar montos aleatorios para cada categoría
        const counterSales = Math.floor(Math.random() * 3000000) + 1000000
        const deliverySales = Math.floor(Math.random() * 2000000) + 500000
        const payrollExpenses = Math.floor(Math.random() * 1000000) + 500000
        const rentExpenses = Math.floor(Math.random() * 300000) + 200000
        const maintenanceExpenses = Math.floor(Math.random() * 100000) + 50000
        const suppliesExpenses = Math.floor(Math.random() * 500000) + 300000
        const repairsExpenses = Math.floor(Math.random() * 100000) + 20000
        const otherExpenses = Math.floor(Math.random() * 100000) + 10000

        // Calcular totales
        const totalIncome = counterSales + deliverySales
        const totalExpenses =
          payrollExpenses + rentExpenses + maintenanceExpenses + suppliesExpenses + repairsExpenses + otherExpenses
        const netProfit = totalIncome - totalExpenses

        balances.push({
          id: `${local}-${year}-${month}`,
          localId: local,
          local,
          month,
          year,
          counterSales,
          deliverySales,
          payrollExpenses,
          rentExpenses,
          maintenanceExpenses,
          suppliesExpenses,
          repairsExpenses,
          otherExpenses,
          totalIncome,
          totalExpenses,
          netProfit,
        })
      }
    })

  return balances
}

const balances = generateBalances()

// Servicio para interactuar con los datos
export const dbService = {
  // Empleados
  getEmployees: async (filters?: Partial<Employee>): Promise<Employee[]> => {
    let filteredEmployees = [...employees]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredEmployees = filteredEmployees.filter((emp) => {
            const empValue = emp[key as keyof Employee]
            if (typeof empValue === "string" && typeof value === "string") {
              return empValue.toLowerCase().includes(value.toLowerCase())
            }
            return empValue === value
          })
        }
      })
    }

    return filteredEmployees
  },

  getEmployeeById: async (id: string): Promise<Employee | undefined> => {
    return employees.find((emp) => emp.id === id)
  },

  createEmployee: async (employee: Omit<Employee, "id">): Promise<Employee> => {
    const newEmployee = {
      ...employee,
      id: (employees.length + 1).toString(),
    }
    employees.push(newEmployee)
    return newEmployee
  },

  updateEmployee: async (id: string, employee: Partial<Employee>): Promise<Employee | undefined> => {
    const index = employees.findIndex((emp) => emp.id === id)
    if (index !== -1) {
      employees[index] = { ...employees[index], ...employee }

      // Si se agrega fecha de terminación, cambiar estado a inactivo y calcular días trabajados
      if (employee.terminationDate && employees[index].status === "active") {
        employees[index].status = "inactive"

        // Calcular días trabajados
        const hireDate = new Date(employees[index].hireDate)
        const terminationDate = new Date(employee.terminationDate)
        const diffTime = Math.abs(terminationDate.getTime() - hireDate.getTime())
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))

        employees[index].workedDays = diffDays
      }

      return employees[index]
    }
    return undefined
  },

  deleteEmployee: async (id: string): Promise<boolean> => {
    const index = employees.findIndex((emp) => emp.id === id)
    if (index !== -1) {
      employees.splice(index, 1)
      return true
    }
    return false
  },

  // Asistencias
  getAttendances: async (filters?: Partial<Attendance>): Promise<Attendance[]> => {
    let filteredAttendances = [...attendances]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredAttendances = filteredAttendances.filter((att) => {
            const attValue = att[key as keyof Attendance]
            if (typeof attValue === "string" && typeof value === "string") {
              return attValue.toLowerCase().includes(value.toLowerCase())
            }
            return attValue === value
          })
        }
      })
    }

    return filteredAttendances
  },

  getAttendanceById: async (id: string): Promise<Attendance | undefined> => {
    return attendances.find((att) => att.id === id)
  },

  createAttendance: async (attendance: Omit<Attendance, "id">): Promise<Attendance> => {
    const newAttendance = {
      ...attendance,
      id: `${attendance.employeeId}-${attendance.date}`,
    }
    attendances.push(newAttendance)
    return newAttendance
  },

  updateAttendance: async (id: string, attendance: Partial<Attendance>): Promise<Attendance | undefined> => {
    const index = attendances.findIndex((att) => att.id === id)
    if (index !== -1) {
      attendances[index] = { ...attendances[index], ...attendance }
      return attendances[index]
    }
    return undefined
  },

  deleteAttendance: async (id: string): Promise<boolean> => {
    const index = attendances.findIndex((att) => att.id === id)
    if (index !== -1) {
      attendances.splice(index, 1)
      return true
    }
    return false
  },

  // Nóminas
  getPayrolls: async (filters?: Partial<Payroll>): Promise<Payroll[]> => {
    let filteredPayrolls = [...payrolls]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredPayrolls = filteredPayrolls.filter((pay) => {
            const payValue = pay[key as keyof Payroll]
            if (typeof payValue === "string" && typeof value === "string") {
              return payValue.toLowerCase().includes(value.toLowerCase())
            }
            return payValue === value
          })
        }
      })
    }

    return filteredPayrolls
  },

  getPayrollById: async (id: string): Promise<Payroll | undefined> => {
    return payrolls.find((pay) => pay.id === id)
  },

  updatePayroll: async (id: string, payroll: Partial<Payroll>): Promise<Payroll | undefined> => {
    const index = payrolls.findIndex((pay) => pay.id === id)
    if (index !== -1) {
      payrolls[index] = { ...payrolls[index], ...payroll }
      return payrolls[index]
    }
    return undefined
  },

  // Generar nómina para un mes específico
  generateMonthlyPayroll: async (month: number, year: number): Promise<Payroll[]> => {
    const newPayrolls: Payroll[] = []
    const newPayrollDetails: PayrollDetail[] = []

    // Obtener empleados activos
    const activeEmployees = await dbService.getEmployees({ status: "active" })

    // Para cada empleado activo, generar su nómina
    for (const employee of activeEmployees) {
      // Obtener asistencias del mes
      const monthAttendances = await dbService.getAttendances({
        employeeId: employee.id,
      })

      // Filtrar por mes y año
      const filteredAttendances = monthAttendances.filter((att) => {
        const attDate = new Date(att.date)
        return attDate.getMonth() + 1 === month && attDate.getFullYear() === year
      })

      // Calcular valor del minuto
      const dailySalary = employee.totalSalary / 30
      const minuteValue = dailySalary / 480 // 8 horas = 480 minutos

      let totalDeductions = 0
      let totalAdditions = 0

      const payrollId = `${employee.id}-${year}-${month}`

      // Procesar cada asistencia para calcular deducciones y adiciones
      filteredAttendances.forEach((att) => {
        // Deducciones por llegadas tarde
        if (att.lateMinutes > 10) {
          // 10 minutos de tolerancia
          const deductionMinutes = att.lateMinutes - 10
          const deductionAmount = deductionMinutes * minuteValue
          totalDeductions += deductionAmount

          newPayrollDetails.push({
            id: `${payrollId}-late-${att.date}`,
            payrollId,
            type: "deduction",
            concept: `Llegada tarde (${deductionMinutes} min)`,
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Deducciones por salidas anticipadas
        if (att.earlyDepartureMinutes > 0) {
          const deductionAmount = att.earlyDepartureMinutes * minuteValue
          totalDeductions += deductionAmount

          newPayrollDetails.push({
            id: `${payrollId}-early-${att.date}`,
            payrollId,
            type: "deduction",
            concept: `Salida anticipada (${att.earlyDepartureMinutes} min)`,
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Deducciones por ausencias injustificadas
        if (att.isAbsent && !att.isJustified) {
          const deductionAmount = dailySalary
          totalDeductions += deductionAmount

          newPayrollDetails.push({
            id: `${payrollId}-absent-${att.date}`,
            payrollId,
            type: "deduction",
            concept: "Ausencia injustificada",
            amount: deductionAmount,
            date: att.date,
          })
        }

        // Adiciones por feriados trabajados
        if (att.isHoliday && !att.isAbsent) {
          const additionAmount = dailySalary
          totalAdditions += additionAmount

          newPayrollDetails.push({
            id: `${payrollId}-holiday-${att.date}`,
            payrollId,
            type: "addition",
            concept: "Feriado trabajado",
            amount: additionAmount,
            date: att.date,
          })
        }
      })

      // Calcular salario final
      const finalHandSalary = employee.baseSalary - totalDeductions + totalAdditions

      // Crear la nómina
      const newPayroll: Payroll = {
        id: payrollId,
        employeeId: employee.id,
        month,
        year,
        baseSalary: employee.baseSalary,
        bankSalary: employee.bankSalary,
        deductions: totalDeductions,
        additions: totalAdditions,
        finalHandSalary,
        totalSalary: finalHandSalary + employee.bankSalary,
        isPaidHand: false,
        isPaidBank: false,
        details: newPayrollDetails.filter((detail) => detail.payrollId === payrollId),
      }

      newPayrolls.push(newPayroll)
    }

    // Agregar las nuevas nóminas a la lista existente
    payrolls.push(...newPayrolls)
    payrollDetails.push(...newPayrollDetails)

    return newPayrolls
  },

  // Estadísticas de delivery
  getDeliveryStats: async (filters?: Partial<DeliveryStats>): Promise<DeliveryStats[]> => {
    let filteredStats = [...deliveryStats]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredStats = filteredStats.filter((stat) => {
            const statValue = stat[key as keyof DeliveryStats]
            if (typeof statValue === "string" && typeof value === "string") {
              return statValue.toLowerCase().includes(value.toLowerCase())
            }
            return statValue === value
          })
        }
      })
    }

    return filteredStats
  },

  createDeliveryStat: async (stat: Omit<DeliveryStats, "id">): Promise<DeliveryStats> => {
    const newStat = {
      ...stat,
      id: `${stat.platform}-${stat.local}-${stat.year}-${stat.week}`,
    }
    deliveryStats.push(newStat)
    return newStat
  },

  updateDeliveryStat: async (id: string, stat: Partial<DeliveryStats>): Promise<DeliveryStats | undefined> => {
    const index = deliveryStats.findIndex((s) => s.id === id)
    if (index !== -1) {
      deliveryStats[index] = { ...deliveryStats[index], ...stat }
      return deliveryStats[index]
    }
    return undefined
  },

  deleteDeliveryStat: async (id: string): Promise<boolean> => {
    const index = deliveryStats.findIndex((s) => s.id === id)
    if (index !== -1) {
      deliveryStats.splice(index, 1)
      return true
    }
    return false
  },

  // Auditorías
  getAudits: async (filters?: Partial<Audit>): Promise<Audit[]> => {
    let filteredAudits = [...audits]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredAudits = filteredAudits.filter((audit) => {
            const auditValue = audit[key as keyof Audit]
            if (typeof auditValue === "string" && typeof value === "string") {
              return auditValue.toLowerCase().includes(value.toLowerCase())
            }
            return auditValue === value
          })
        }
      })
    }

    return filteredAudits
  },

  getAuditById: async (id: string): Promise<Audit | undefined> => {
    return audits.find((audit) => audit.id === id)
  },

  createAudit: async (audit: Omit<Audit, "id">): Promise<Audit> => {
    const newAudit = {
      ...audit,
      id: `${audit.local}-${audit.date}`,
    }
    audits.push(newAudit)
    return newAudit
  },

  updateAudit: async (id: string, audit: Partial<Audit>): Promise<Audit | undefined> => {
    const index = audits.findIndex((a) => a.id === id)
    if (index !== -1) {
      audits[index] = { ...audits[index], ...audit }
      return audits[index]
    }
    return undefined
  },

  deleteAudit: async (id: string): Promise<boolean> => {
    const index = audits.findIndex((a) => a.id === id)
    if (index !== -1) {
      audits.splice(index, 1)
      return true
    }
    return false
  },

  getAuditItems: async (): Promise<AuditItem[]> => {
    return auditItems
  },

  // Facturación
  getBillings: async (filters?: Partial<Billing>): Promise<Billing[]> => {
    let filteredBillings = [...billings]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredBillings = filteredBillings.filter((billing) => {
            const billingValue = billing[key as keyof Billing]
            if (typeof billingValue === "string" && typeof value === "string") {
              return billingValue.toLowerCase().includes(value.toLowerCase())
            }
            return billingValue === value
          })
        }
      })
    }

    return filteredBillings
  },

  getBillingById: async (id: string): Promise<Billing | undefined> => {
    return billings.find((billing) => billing.id === id)
  },

  createBilling: async (billing: Omit<Billing, "id">): Promise<Billing> => {
    const newBilling = {
      ...billing,
      id: `${billing.local}-${billing.year}-${billing.month}`,
    }
    billings.push(newBilling)
    return newBilling
  },

  updateBilling: async (id: string, billing: Partial<Billing>): Promise<Billing | undefined> => {
    const index = billings.findIndex((b) => b.id === id)
    if (index !== -1) {
      billings[index] = { ...billings[index], ...billing }
      return billings[index]
    }
    return undefined
  },

  deleteBilling: async (id: string): Promise<boolean> => {
    const index = billings.findIndex((b) => b.id === id)
    if (index !== -1) {
      billings.splice(index, 1)
      return true
    }
    return false
  },

  // Balances
  getBalances: async (filters?: Partial<Balance>): Promise<Balance[]> => {
    let filteredBalances = [...balances]

    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== "") {
          filteredBalances = filteredBalances.filter((balance) => {
            const balanceValue = balance[key as keyof Balance]
            if (typeof balanceValue === "string" && typeof value === "string") {
              return balanceValue.toLowerCase().includes(value.toLowerCase())
            }
            return balanceValue === value
          })
        }
      })
    }

    return filteredBalances
  },

  getBalanceById: async (id: string): Promise<Balance | undefined> => {
    return balances.find((balance) => balance.id === id)
  },

  createBalance: async (
    balance: Omit<Balance, "id" | "totalIncome" | "totalExpenses" | "netProfit">,
  ): Promise<Balance> => {
    const totalIncome = balance.counterSales + balance.deliverySales
    const totalExpenses =
      balance.payrollExpenses +
      balance.rentExpenses +
      balance.maintenanceExpenses +
      balance.suppliesExpenses +
      balance.repairsExpenses +
      balance.otherExpenses
    const netProfit = totalIncome - totalExpenses

    const newBalance = {
      ...balance,
      id: `${balance.local}-${balance.year}-${balance.month}`,
      totalIncome,
      totalExpenses,
      netProfit,
    }

    balances.push(newBalance)
    return newBalance
  },

  updateBalance: async (id: string, balance: Partial<Balance>): Promise<Balance | undefined> => {
    const index = balances.findIndex((b) => b.id === id)
    if (index !== -1) {
      // Recalcular totales si se actualizan los valores
      const updatedBalance = { ...balances[index], ...balance }

      if (balance.counterSales !== undefined || balance.deliverySales !== undefined) {
        updatedBalance.totalIncome =
          (balance.counterSales ?? updatedBalance.counterSales) +
          (balance.deliverySales ?? updatedBalance.deliverySales)
      }

      if (
        balance.payrollExpenses !== undefined ||
        balance.rentExpenses !== undefined ||
        balance.maintenanceExpenses !== undefined ||
        balance.suppliesExpenses !== undefined ||
        balance.repairsExpenses !== undefined ||
        balance.otherExpenses !== undefined
      ) {
        updatedBalance.totalExpenses =
          (balance.payrollExpenses ?? updatedBalance.payrollExpenses) +
          (balance.rentExpenses ?? updatedBalance.rentExpenses) +
          (balance.maintenanceExpenses ?? updatedBalance.maintenanceExpenses) +
          (balance.suppliesExpenses ?? updatedBalance.suppliesExpenses) +
          (balance.repairsExpenses ?? updatedBalance.repairsExpenses) +
          (balance.otherExpenses ?? updatedBalance.otherExpenses)
      }

      updatedBalance.netProfit = updatedBalance.totalIncome - updatedBalance.totalExpenses

      balances[index] = updatedBalance
      return updatedBalance
    }
    return undefined
  },

  deleteBalance: async (id: string): Promise<boolean> => {
    const index = balances.findIndex((b) => b.id === id)
    if (index !== -1) {
      balances.splice(index, 1)
      return true
    }
    return false
  },

  // Locales
  getLocales: async (): Promise<Local[]> => {
    return locales
  },

  // Estadísticas para el dashboard
  getDashboardStats: async (): Promise<{
    activeEmployees: number
    activeEmployeesChange: number
    totalDeliveryOrders: number
    deliveryOrdersChange: number
    totalRevenue: number
    revenueChange: number
    averageRating: number
    ratingChange: number
  }> => {
    // Contar empleados activos
    const activeEmployees = employees.filter((emp) => emp.status === "active").length

    // Calcular cambio respecto al mes anterior
    const lastMonthDate = new Date()
    lastMonthDate.setMonth(lastMonthDate.getMonth() - 1)
    const lastMonthActiveEmployees = employees.filter(
      (emp) =>
        emp.status === "active" ||
        (emp.status === "inactive" && emp.terminationDate && new Date(emp.terminationDate) > lastMonthDate),
    ).length
    const activeEmployeesChange = Math.round(
      ((activeEmployees - lastMonthActiveEmployees) / lastMonthActiveEmployees) * 100,
    )

    // Calcular total de pedidos de delivery de la semana actual
    const currentDate = new Date()
    const currentWeek = Math.ceil(currentDate.getDate() / 7)
    const currentYear = currentDate.getFullYear()

    const currentWeekStats = deliveryStats.filter((stat) => stat.week === currentWeek && stat.year === currentYear)
    const totalDeliveryOrders = currentWeekStats.reduce((sum, stat) => sum + stat.orderCount, 0)

    // Calcular total de pedidos de la semana anterior
    const prevWeek = currentWeek === 1 ? 52 : currentWeek - 1
    const prevYear = currentWeek === 1 ? currentYear - 1 : currentYear

    const prevWeekStats = deliveryStats.filter((stat) => stat.week === prevWeek && stat.year === prevYear)
    const prevWeekOrders = prevWeekStats.reduce((sum, stat) => sum + stat.orderCount, 0)

    const deliveryOrdersChange =
      prevWeekOrders === 0 ? 0 : Math.round(((totalDeliveryOrders - prevWeekOrders) / prevWeekOrders) * 100)

    // Calcular ingresos totales de la semana actual
    const totalRevenue = currentWeekStats.reduce((sum, stat) => sum + stat.revenue, 0)

    // Calcular ingresos de la semana anterior
    const prevWeekRevenue = prevWeekStats.reduce((sum, stat) => sum + stat.revenue, 0)

    const revenueChange =
      prevWeekRevenue === 0 ? 0 : Math.round(((totalRevenue - prevWeekRevenue) / prevWeekRevenue) * 100)

    // Calcular valoración promedio
    const totalRating = currentWeekStats.reduce((sum, stat) => sum + stat.rating, 0)
    const averageRating = currentWeekStats.length === 0 ? 0 : totalRating / currentWeekStats.length

    // Calcular valoración promedio de la semana anterior
    const prevWeekRating = prevWeekStats.reduce((sum, stat) => sum + stat.rating, 0)
    const prevWeekAverageRating = prevWeekStats.length === 0 ? 0 : prevWeekRating / prevWeekStats.length

    const ratingChange =
      prevWeekAverageRating === 0 ? 0 : ((averageRating - prevWeekAverageRating) / prevWeekAverageRating) * 100

    return {
      activeEmployees,
      activeEmployeesChange,
      totalDeliveryOrders,
      deliveryOrdersChange,
      totalRevenue,
      revenueChange,
      averageRating,
      ratingChange: Math.round(ratingChange * 10) / 10, // Redondear a 1 decimal
    }
  },

  // Generar reportes
  generateReports: async (): Promise<Report[]> => {
    const reports: Report[] = []

    // Reporte 1: Facturación de todos los locales mes a mes
    const billingsByMonth = await dbService.getBillings()
    const billingData = {
      labels: Array.from(new Set(billingsByMonth.map((b) => `${b.month}/${b.year}`))),
      datasets: locales
        .filter((local) => local !== "Administración")
        .map((local) => {
          const localBillings = billingsByMonth.filter((b) => b.local === local)
          return {
            label: local,
            data: localBillings.map((b) => b.amount),
          }
        }),
    }

    reports.push({
      id: "1",
      name: "Facturación por Local",
      type: "bar",
      data: billingData,
      createdAt: new Date().toISOString(),
    })

    // Reporte 2: Facturación vs Gastos de Nómina
    const allBalances = await dbService.getBalances()
    const facturacionVsNomina = {
      labels: Array.from(new Set(allBalances.map((b) => `${b.month}/${b.year}`))),
      datasets: [
        {
          label: "Facturación Total",
          data: allBalances.map((b) => b.totalIncome),
        },
        {
          label: "Gastos de Nómina",
          data: allBalances.map((b) => b.payrollExpenses),
        },
      ],
    }

    reports.push({
      id: "2",
      name: "Facturación vs Gastos de Nómina",
      type: "bar",
      data: facturacionVsNomina,
      createdAt: new Date().toISOString(),
    })

    // Reporte 3: Evolución de Delivery por Plataforma
    const allDeliveryStats = await dbService.getDeliveryStats()
    const deliveryEvolution = {
      labels: Array.from(new Set(allDeliveryStats.map((d) => `Semana ${d.week}/${d.year}`))),
      datasets: ["PedidosYa", "Rappi", "MercadoPago"].map((platform) => {
        const platformStats = allDeliveryStats.filter((d) => d.platform === platform)
        return {
          label: platform,
          data: platformStats.map((d) => d.orderCount),
        }
      }),
    }

    reports.push({
      id: "3",
      name: "Evolución de Pedidos por Plataforma",
      type: "line",
      data: deliveryEvolution,
      createdAt: new Date().toISOString(),
    })

    // Reporte 4: Distribución de Ingresos por Local
    const currentMonth = new Date().getMonth() + 1
    const currentYear = new Date().getFullYear()
    const currentMonthBalances = allBalances.filter((b) => b.month === currentMonth && b.year === currentYear)

    const ingresosPorLocal = {
      labels: currentMonthBalances.map((b) => b.local),
      datasets: [
        {
          label: "Ingresos Totales",
          data: currentMonthBalances.map((b) => b.totalIncome),
        },
      ],
    }

    reports.push({
      id: "4",
      name: "Distribución de Ingresos por Local",
      type: "pie",
      data: ingresosPorLocal,
      createdAt: new Date().toISOString(),
    })

    return reports
  },
}

