"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import type { LoginCredentials, AuthState, UserRole } from "@/types/auth"

// Datos de ejemplo para usuarios
const MOCK_USERS = [
  {
    id: "1",
    email: "admin@quadrifoglio.com",
    password: "admin123",
    name: "Administrador",
    role: "admin" as UserRole,
    isActive: true,
  },
  {
    id: "2",
    email: "gerente@quadrifoglio.com",
    password: "gerente123",
    name: "Gerente",
    role: "manager" as UserRole,
    local: "Centro",
    isActive: true,
  },
  {
    id: "3",
    email: "empleado@quadrifoglio.com",
    password: "empleado123",
    name: "Empleado",
    role: "employee" as UserRole,
    local: "Centro",
    isActive: true,
  },
  {
    id: "4",
    email: "cajero@quadrifoglio.com",
    password: "cajero123",
    name: "Cajero",
    role: "cashier" as UserRole,
    local: "Centro",
    isActive: true,
  },
  {
    id: "5",
    email: "mesero@quadrifoglio.com",
    password: "mesero123",
    name: "Mesero",
    role: "waiter" as UserRole,
    local: "Centro",
    isActive: true,
  },
  {
    id: "6",
    email: "cocina@quadrifoglio.com",
    password: "cocina123",
    name: "Cocinero",
    role: "kitchen" as UserRole,
    local: "Centro",
    isActive: true,
  },
]

// Rutas públicas que no requieren autenticación
const PUBLIC_ROUTES = ["/login", "/forgot-password"]

// Rutas permitidas por rol
const ROLE_ROUTES: Record<UserRole, string[]> = {
  admin: ["*"], // El admin tiene acceso a todas las rutas
  manager: ["/", "/empleados", "/empleados/*", "/nomina/*", "/asistencias", "/ventas", "/facturacion"],
  employee: ["/", "/asistencias"],
  cashier: ["/", "/facturacion", "/ventas"],
  waiter: ["/", "/ventas"],
  kitchen: ["/"],
}

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<boolean>
  logout: () => void
  hasPermission: (route: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  })

  const router = useRouter()
  const pathname = usePathname()

  // Cargar usuario desde localStorage al iniciar
  useEffect(() => {
    try {
      const storedUser = localStorage.getItem("user")
      if (storedUser) {
        const user = JSON.parse(storedUser)
        setAuthState({
          user,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        })
      } else {
        setAuthState((prev) => ({ ...prev, isLoading: false }))
      }
    } catch (error) {
      console.error("Error loading user from localStorage:", error)
      localStorage.removeItem("user")
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      })
    }
  }, [])

  // Verificar permisos de ruta cuando cambia la ruta o el usuario
  useEffect(() => {
    if (!authState.isLoading) {
      // Si es una ruta pública, permitir acceso
      if (PUBLIC_ROUTES.includes(pathname)) {
        return
      }

      // Si no está autenticado, redirigir a login
      if (!authState.isAuthenticated) {
        router.push("/login")
        return
      }

      // Si está autenticado pero no tiene permiso para la ruta actual
      // Comentamos esta parte para evitar redirecciones innecesarias por ahora
      /*
      if (!hasPermissionForRoute(pathname)) {
        router.push("/");
      }
      */
    }
  }, [pathname, authState.isAuthenticated, authState.isLoading, authState.user?.role, router])

  // Función para verificar si el usuario tiene permiso para una ruta
  const hasPermissionForRoute = (route: string): boolean => {
    if (!authState.user) return false

    const userRole = authState.user.role
    const allowedRoutes = ROLE_ROUTES[userRole]

    // Si tiene acceso a todas las rutas
    if (allowedRoutes.includes("*")) return true

    // Verificar rutas exactas
    if (allowedRoutes.includes(route)) return true

    // Verificar rutas con comodín (por ejemplo, /empleados/*)
    return allowedRoutes.some((allowedRoute) => {
      if (allowedRoute.endsWith("/*")) {
        const baseRoute = allowedRoute.replace("/*", "")
        return route.startsWith(baseRoute)
      }
      return false
    })
  }

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    setAuthState((prev) => ({ ...prev, isLoading: true, error: null }))

    try {
      // Simulación de autenticación con datos de ejemplo
      const user = MOCK_USERS.find((u) => u.email === credentials.email && u.password === credentials.password)

      if (!user) {
        setAuthState({
          user: null,
          isAuthenticated: false,
          isLoading: false,
          error: "Credenciales inválidas",
        })
        return false
      }

      // Omitir la contraseña del objeto de usuario
      const { password, ...userWithoutPassword } = user

      // Guardar en localStorage
      localStorage.setItem("user", JSON.stringify(userWithoutPassword))

      setAuthState({
        user: userWithoutPassword,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      })

      return true
    } catch (error) {
      console.error("Error during login:", error)
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: "Error al iniciar sesión",
      })
      return false
    }
  }

  const logout = () => {
    try {
      localStorage.removeItem("user")
      setAuthState({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      })
      router.push("/login")
    } catch (error) {
      console.error("Error during logout:", error)
    }
  }

  const hasPermission = (route: string): boolean => {
    return hasPermissionForRoute(route)
  }

  return (
    <AuthContext.Provider
      value={{
        ...authState,
        login,
        logout,
        hasPermission,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

