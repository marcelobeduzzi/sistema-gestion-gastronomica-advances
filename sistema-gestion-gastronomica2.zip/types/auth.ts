export type UserRole = "admin" | "manager" | "employee" | "cashier" | "waiter" | "kitchen"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  local?: string
  isActive: boolean
  lastLogin?: Date
}

export interface Permission {
  id: string
  name: string
  description: string
  roles: UserRole[]
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
}

