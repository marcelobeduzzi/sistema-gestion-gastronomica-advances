// Tipos comunes para todo el sistema

export type UserRole = "admin" | "manager" | "employee" | "cashier" | "waiter" | "kitchen" | "supervisor"

export type EmployeeStatus = "active" | "inactive" | "on_leave" | "vacation"

export type Local =
  | "BR Cabildo"
  | "BR Carranza"
  | "BR Pacifico"
  | "BR Lavalle"
  | "BR Rivadavia"
  | "BR Aguero"
  | "BR Dorrego"
  | "Dean & Dennys"
  | "Administración"

export type WorkShift = "morning" | "afternoon" | "night" | "full_time" | "part_time"

export type DeliveryPlatform = "PedidosYa" | "Rappi" | "MercadoPago"

export interface Employee {
  id: string
  firstName: string
  lastName: string
  documentId: string
  documentType: string
  phone: string
  email: string
  address: string
  birthDate: string
  hireDate: string
  terminationDate?: string
  position: string
  local: Local
  workShift: WorkShift
  baseSalary: number
  bankSalary: number
  totalSalary: number
  status: EmployeeStatus
  role: UserRole
  workedDays?: number
}

export interface Attendance {
  id: string
  employeeId: string
  date: string
  checkIn: string
  checkOut: string
  expectedCheckIn: string
  expectedCheckOut: string
  lateMinutes: number
  earlyDepartureMinutes: number
  isHoliday: boolean
  isAbsent: boolean
  isJustified: boolean
  justificationDocument?: string
  notes?: string
}

export interface Payroll {
  id: string
  employeeId: string
  month: number
  year: number
  baseSalary: number
  bankSalary: number
  deductions: number
  additions: number
  finalHandSalary: number
  totalSalary: number
  isPaidHand: boolean
  isPaidBank: boolean
  handPaymentDate?: string
  bankPaymentDate?: string
  details: PayrollDetail[]
}

export interface PayrollDetail {
  id: string
  payrollId: string
  type: "deduction" | "addition"
  concept: string
  amount: number
  date: string
}

export interface DeliveryStats {
  id: string
  platform: DeliveryPlatform
  week: number
  year: number
  orderCount: number
  revenue: number
  complaints: number
  rating: number
  local: Local
}

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  local?: Local
  isActive: boolean
  lastLogin?: Date
}

export interface AuditItem {
  id: string
  category: string
  name: string
  value: number
  completed: boolean
}

export interface Audit {
  id: string
  localId: string
  local: Local
  date: string
  shift: WorkShift
  supervisorId: string
  supervisorName: string
  managerId: string
  managerName: string
  totalScore: number
  items: AuditItem[]
}

export interface Billing {
  id: string
  localId: string
  local: Local
  month: number
  year: number
  amount: number
}

export interface Balance {
  id: string
  localId: string
  local: Local
  month: number
  year: number
  counterSales: number
  deliverySales: number
  payrollExpenses: number
  rentExpenses: number
  maintenanceExpenses: number
  suppliesExpenses: number
  repairsExpenses: number
  otherExpenses: number
  totalIncome: number
  totalExpenses: number
  netProfit: number
}

export interface Report {
  id: string
  name: string
  type: "bar" | "pie" | "line"
  data: any
  createdAt: string
}

